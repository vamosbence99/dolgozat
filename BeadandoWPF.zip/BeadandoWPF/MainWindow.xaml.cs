﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Beadando
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Szamla> invoice = new List<Szamla>();

        Szamla i = new Szamla();

        Mag c = new Mag();
        int ertek;
        public MainWindow()
        {
            invoice.Add(new Szamla { OwnerName = "1"});
            invoice.Add(new Szamla { OwnerName = "2"});
            InitializeComponent();

            TBox1fent.Text = invoice[0].OwnerName;
            TBox2fent.Text = invoice[1].OwnerName;
            TBox1kozep.Text = invoice[0].Balance.ToString();
            TBox2kozep.Text = invoice[1].Balance.ToString();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            ertek = c.Feltolt(TextBox1lent.Text, TBox1kozep.Text);

            if (ertek!=-1)
            {
                invoice[0].Balance = ertek;
                TBox1kozep.Text = invoice[0].Balance.ToString();

            }
            else 
            {
                MessageBox.Show("Adjon meg egy pozitív számot!", "Sikertelen", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void Upload2(object sender, RoutedEventArgs e)
        {
            ertek = c.Feltolt(TextBox2lent.Text, TBox2kozep.Text);
            if (ertek!=-1)
            {
                invoice[1].Balance = ertek;
                TBox2kozep.Text = invoice[1].Balance.ToString();

            }
            else
            {
                MessageBox.Show("Adjon meg egy pozitív számot!", "Sikertelen", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void KivetelAlfa(object sender, RoutedEventArgs e)
        {
            ertek = c.Kivesz(TBox1kozep.Text, TextBox1lent.Text);
            if (ertek != -1)
            {
                invoice[0].Balance = ertek;
                TBox1kozep.Text = invoice[0].Balance.ToString();
            }
            else
            {
                MessageBox.Show("Adjon meg egy pozitív számot, vagy kisebb számot, mint az egyenlege!", "Sikertelen", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void KivetelBeta(object sender, RoutedEventArgs e)
        {
            ertek = c.Kivesz(TBox2kozep.Text, TextBox2lent.Text);
            if (ertek != -1)
            {
                invoice[0].Balance = ertek;
                TBox2kozep.Text = invoice[0].Balance.ToString();

            }
            else
            {
                MessageBox.Show("Adjon meg egy pozitív számot, vagy kisebb számot, mint az egyenlege!", "Sikertelen", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Utalas1(object sender, RoutedEventArgs e)
        {
            //először kivonok a Balancebol
            //majd a másik Balancához hozzáadom

            string KivonasFeltoltes = TextBox1lent.Text;
            ertek = c.Kivesz(TBox1kozep.Text, TextBox1lent.Text);
            if (ertek != -1)
            {
                invoice[0].Balance = ertek;
                TBox1kozep.Text = invoice[0].Balance.ToString();

                ertek = c.Feltolt(KivonasFeltoltes, TBox2kozep.Text);
                //if (!ertek.ToString().Contains("Exception"))
                //{
                    invoice[1].Balance = ertek;
                    TBox2kozep.Text = invoice[1].Balance.ToString();

                //}
            }
            else
            {
                MessageBox.Show("Adjon meg egy pozitív számot, vagy kisebb számot, mint az egyenlege!", "Sikertelen", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }

        private void UtalasBeta(object sender, RoutedEventArgs e)
        {
            string KivonasFeltoltes = TextBox2lent.Text;
            ertek = c.Kivesz(TBox2kozep.Text, TextBox1lent.Text);
            if (ertek != -1)
            {
                invoice[1].Balance = ertek;
                TBox2kozep.Text = invoice[1].Balance.ToString();

                ertek = c.Feltolt(KivonasFeltoltes, TBox1kozep.Text);
                //if (!ertek.ToString().Contains("Exception"))
                //{
                    invoice[0].Balance = ertek;
                    TBox1kozep.Text = invoice[0].Balance.ToString();

                //}

            }
            else
            {
                MessageBox.Show("Adjon meg egy pozitív számot, vagy kisebb számot, mint az egyenlege!", "Sikertelen", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TulajNevValtbal(object sender, RoutedEventArgs e)
        {
            
                //TextBoxWrL jelenjeg meg TBoxU1-ben
                invoice[0].OwnerName = TextBox1lent.Text;
                TBox1fent.Text = invoice[0].OwnerName;
           
            
        }

        private void TulajNevValtjobb(object sender, RoutedEventArgs e)
        {
            invoice[1].OwnerName = TextBox2lent.Text;
            TBox2fent.Text = invoice[1].OwnerName;
        }
    }
}
