﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Beadando
{
    public class Mag
    {
        public Mag() { }

        int ertek = 0;//segédváltozó

        //Invoice i = new Invoice();
        public int Feltolt(string e1, string e2)//e1=érték1
        {
            //if (string.IsNullOrEmpty(e1))
            //{
            //    throw new ArgumentException($"'{nameof(e1)}' cannot be null or empty.", nameof(e1));
            //}
            if (e1 == "")
            {
               //throw new FormatException();
               return ertek=-1;
            }
            //else 
            //{
            //try
            //{
                int sz1 = Convert.ToInt32(e1);
                int sz2 = Convert.ToInt32(e2);

            if (sz1 >= 0)
            {
                ertek = sz1 + sz2;
                return ertek;
            }

            else { /*throw new FormatException();*/ return ertek=-1; }
            //}
            //catch (Exception e)
            //{
            //    i.ErrorMessage = e.Message;
            //    MessageBox.Show(e.Message);
            //}
            

            //}
        }
        public int Kivesz(string ossz, string kivon)
        {
            if (kivon == "")
            {
                //throw new FormatException();
                return ertek = -1;
            }
            
            int SzOssz = Convert.ToInt32(ossz);
            int SzKivon = Convert.ToInt32(kivon);

                if (SzOssz >= 0 && SzKivon >= 0)
                {
                ertek = SzOssz - SzKivon;
                return ertek;
                }
                else
                {
                return ertek = -1;
                }

        }

    }
}
